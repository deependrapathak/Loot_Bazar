package cs545.mum.edu.Loot_Bazar.model;

public enum Role {
  ROLE_ADMIN,ROLE_CUSTOMER
}
