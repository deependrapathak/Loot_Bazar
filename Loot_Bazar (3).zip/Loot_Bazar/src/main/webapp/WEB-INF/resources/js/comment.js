$(document).ready(function() {

	addReviewForm= function() { 
		
			$("#newComment").attr("style", "display: block")
	 		} 
	 
	hideAddForm= function(){
		$("#newComment").attr("style", "display: none")
	} 	   
	
	commentAdd = function(){
		//$("#newComment").attr("style", "display: block")
		var dataToSend = JSON.stringify(serializeObject($('#reviewForm')));
		$.ajax({
				  url: '/Loot_Bazar/addReviews',
				 type: 'POST',
				  dataType: "json",  
				  data:dataToSend,
				  contentType: 'application/json', 
				  success: function(review){
					  $('#errors').html("");
					  alert("Thank You!!!"+review.name);
					  },
					  error: function(jqXHR, textStatus, exception ){
						  alert(dataToSend),
						  alert("please try again!! errors occure"+exception);
						 /* if (jqXHR.responseJSON.errorType == "ValidationError") {
							  
							  $("#errors").append( '<H3 align="center"> Error(s)!!  <H3>');
							  $("#errors").append( '<p>');
							   var errorList = jqXHR.responseJSON.errors;
							    $.each(errorList, function(i,error) { 
							    	
							    	$("#errors").append( error.message + '<br>');
							   });
							    
							   $("#errors").append( '</p>');
							   
							  }
							  else {
							  alert(jqXHR.responseJSON.message);
							  }*/

					  }

		})
		
		function serializeObject (form)
		{
		    var jsonObject = {};
		    var array = form.serializeArray();
		    $.each(array, function() {
		         	jsonObject[this.name] = this.value;
		    });
		    return jsonObject;

		}
	}
})