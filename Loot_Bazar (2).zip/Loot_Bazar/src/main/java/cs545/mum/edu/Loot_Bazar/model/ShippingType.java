package cs545.mum.edu.Loot_Bazar.model;

public enum ShippingType {
	BYBUS, BYSHIP, BYAIR
}
